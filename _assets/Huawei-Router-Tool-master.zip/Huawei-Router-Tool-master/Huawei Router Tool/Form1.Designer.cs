﻿namespace Huawei_Router_Tool_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.backgroundWorkerDeviceInfo = new System.ComponentModel.BackgroundWorker();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.backgroundWorkerLetMeSeeUrs = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorkerApplyBand = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorkerPerformanceTool = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorkerAPI = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorkerLogin_Reboot_Shutdown = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorkerSpeedtest = new System.ComponentModel.BackgroundWorker();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.backgroundWorkerCOnnectedDeviceAndMacFilter = new System.ComponentModel.BackgroundWorker();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.buttonApplyWLAN = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.buttonShutdown = new MetroFramework.Controls.MetroButton();
            this.buttonReboot = new MetroFramework.Controls.MetroButton();
            this.buttonLogin = new MetroFramework.Controls.MetroButton();
            this.checkBoxRememberUserpass = new MetroFramework.Controls.MetroCheckBox();
            this.textBoxPassword = new MetroFramework.Controls.MetroTextBox();
            this.textBoxUsername = new MetroFramework.Controls.MetroTextBox();
            this.textBoxIP = new MetroFramework.Controls.MetroTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroButtonSIGNALMONITOR = new MetroFramework.Controls.MetroButton();
            this.textBoxRSSI = new MetroFramework.Controls.MetroTextBox();
            this.textBoxSINR = new MetroFramework.Controls.MetroTextBox();
            this.textBoxRSRQ = new MetroFramework.Controls.MetroTextBox();
            this.textBoxRSRP = new MetroFramework.Controls.MetroTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBoxCurrentDownloadRate = new MetroFramework.Controls.MetroTextBox();
            this.textBoxCurrentUploadRate = new MetroFramework.Controls.MetroTextBox();
            this.textBoxCurrentConnectTime = new MetroFramework.Controls.MetroTextBox();
            this.textBoxTotalUpload = new MetroFramework.Controls.MetroTextBox();
            this.textBoxTotalDownload = new MetroFramework.Controls.MetroTextBox();
            this.textBoxMNC = new MetroFramework.Controls.MetroTextBox();
            this.textBoxTotalConnectTime = new MetroFramework.Controls.MetroTextBox();
            this.textBoxModel = new MetroFramework.Controls.MetroTextBox();
            this.textBoxSerialNumber = new MetroFramework.Controls.MetroTextBox();
            this.textBoxImei = new MetroFramework.Controls.MetroTextBox();
            this.textBoxIccid = new MetroFramework.Controls.MetroTextBox();
            this.textBoxMsisdn = new MetroFramework.Controls.MetroTextBox();
            this.textBoxHardwareVersion = new MetroFramework.Controls.MetroTextBox();
            this.textBoxSoftwareVersion = new MetroFramework.Controls.MetroTextBox();
            this.textBoxMacAddress = new MetroFramework.Controls.MetroTextBox();
            this.textBoxWorkmode = new MetroFramework.Controls.MetroTextBox();
            this.textBoxNetworkProvider = new MetroFramework.Controls.MetroTextBox();
            this.textBoxsimLock = new MetroFramework.Controls.MetroTextBox();
            this.textBoxWebuiVersion = new MetroFramework.Controls.MetroTextBox();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label21 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.buttonRestore = new MetroFramework.Controls.MetroButton();
            this.comboBoxDeviceMode = new MetroFramework.Controls.MetroComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBoxSIP = new MetroFramework.Controls.MetroTextBox();
            this.textBoxDMZ = new MetroFramework.Controls.MetroTextBox();
            this.checkBoxDMZ = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxNAT = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxSIP = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxUPnP = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxMobileConnection = new MetroFramework.Controls.MetroCheckBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.buttonSaveDevicePW = new MetroFramework.Controls.MetroButton();
            this.textBoxNewPW = new MetroFramework.Controls.MetroTextBox();
            this.textBoxCurrentPW = new MetroFramework.Controls.MetroTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.checkBoxFW3 = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxFW2 = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxFW1 = new MetroFramework.Controls.MetroCheckBox();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.buttonRefreshConnectedClient = new MetroFramework.Controls.MetroButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.buttonUnblockAll = new MetroFramework.Controls.MetroButton();
            this.buttonBlockDevice = new MetroFramework.Controls.MetroButton();
            this.textBoxBlockMAC0 = new MetroFramework.Controls.MetroTextBox();
            this.textBoxBlockMAC1 = new MetroFramework.Controls.MetroTextBox();
            this.textBoxBlockMAC2 = new MetroFramework.Controls.MetroTextBox();
            this.textBoxBlockMAC3 = new MetroFramework.Controls.MetroTextBox();
            this.textBoxBlockMAC4 = new MetroFramework.Controls.MetroTextBox();
            this.textBoxBlockMAC5 = new MetroFramework.Controls.MetroTextBox();
            this.textBoxBlockMAC9 = new MetroFramework.Controls.MetroTextBox();
            this.textBoxBlockMAC6 = new MetroFramework.Controls.MetroTextBox();
            this.textBoxBlockMAC8 = new MetroFramework.Controls.MetroTextBox();
            this.textBoxBlockMAC7 = new MetroFramework.Controls.MetroTextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.buttonAuto = new MetroFramework.Controls.MetroButton();
            this.button4G = new MetroFramework.Controls.MetroButton();
            this.button3G = new MetroFramework.Controls.MetroButton();
            this.button2G = new MetroFramework.Controls.MetroButton();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.checkBoxOLED_Password = new MetroFramework.Controls.MetroCheckBox();
            this.label51 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.buttonGetCurrentStat = new MetroFramework.Controls.MetroButton();
            this.textBoxLTE_Band = new MetroFramework.Controls.MetroTextBox();
            this.textBoxNetworkband = new MetroFramework.Controls.MetroTextBox();
            this.textBoxNetworkMode = new MetroFramework.Controls.MetroTextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkBoxB3 = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxB7 = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxB8 = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxB40 = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxB38 = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxB20 = new MetroFramework.Controls.MetroCheckBox();
            this.checkBoxB1 = new MetroFramework.Controls.MetroCheckBox();
            this.buttonApplyBand = new MetroFramework.Controls.MetroButton();
            this.label32 = new System.Windows.Forms.Label();
            this.metroTabPage5 = new MetroFramework.Controls.MetroTabPage();
            this.comboBoxAPIList = new MetroFramework.Controls.MetroComboBox();
            this.buttonpostAPI = new MetroFramework.Controls.MetroButton();
            this.buttonApplyAPI = new MetroFramework.Controls.MetroButton();
            this.comboBoxAPIs = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.metroTabPage9 = new MetroFramework.Controls.MetroTabPage();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.btnSMSSend = new MetroFramework.Controls.MetroButton();
            this.label42 = new System.Windows.Forms.Label();
            this.rtbSMSContent = new System.Windows.Forms.RichTextBox();
            this.rtbSMSRecipient = new MetroFramework.Controls.MetroTextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroTabPage8 = new MetroFramework.Controls.MetroTabPage();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.tbUSSDCMD = new MetroFramework.Controls.MetroTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.metroTabPage6 = new MetroFramework.Controls.MetroTabPage();
            this.richTextBoxLog = new System.Windows.Forms.RichTextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.buttonDeleteProfile = new System.Windows.Forms.Button();
            this.buttonAddProfile = new System.Windows.Forms.Button();
            this.buttonViewProfileList = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBoxWLANSec = new System.Windows.Forms.ComboBox();
            this.checkBoxEnableSSID = new System.Windows.Forms.CheckBox();
            this.textBoxPre_shared = new System.Windows.Forms.TextBox();
            this.textBoxSSID = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveDeviceInfoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metroTabPage7 = new MetroFramework.Controls.MetroTabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.AboutLog = new System.Windows.Forms.RichTextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttonWebpage = new MetroFramework.Controls.MetroButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.backgroundWorkerDetect_eerorCODE = new System.ComponentModel.BackgroundWorker();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copyPhoneNumberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnRefreshMAC = new MetroFramework.Controls.MetroButton();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.metroTabPage3.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.metroTabPage4.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.metroTabPage5.SuspendLayout();
            this.metroTabPage9.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.metroTabPage8.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.metroTabPage6.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.metroTabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // backgroundWorkerDeviceInfo
            // 
            this.backgroundWorkerDeviceInfo.WorkerSupportsCancellation = true;
            this.backgroundWorkerDeviceInfo.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerDeviceInfo_DoWork);
            this.backgroundWorkerDeviceInfo.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorkerDeviceInfo_RunWorkerCompleted);
            // 
            // backgroundWorkerLetMeSeeUrs
            // 
            this.backgroundWorkerLetMeSeeUrs.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerLetMeSeeUrs_DoWork);
            // 
            // backgroundWorkerApplyBand
            // 
            this.backgroundWorkerApplyBand.WorkerSupportsCancellation = true;
            this.backgroundWorkerApplyBand.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerBand_Tool_DoWork);
            // 
            // backgroundWorkerPerformanceTool
            // 
            this.backgroundWorkerPerformanceTool.WorkerSupportsCancellation = true;
            this.backgroundWorkerPerformanceTool.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerBandTool_DoWork);
            this.backgroundWorkerPerformanceTool.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorkerBandTool_RunWorkerCompleted);
            // 
            // backgroundWorkerAPI
            // 
            this.backgroundWorkerAPI.WorkerSupportsCancellation = true;
            this.backgroundWorkerAPI.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerAPI_DoWork);
            this.backgroundWorkerAPI.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorkerAPI_RunWorkerCompleted);
            // 
            // backgroundWorkerLogin_Reboot_Shutdown
            // 
            this.backgroundWorkerLogin_Reboot_Shutdown.WorkerSupportsCancellation = true;
            this.backgroundWorkerLogin_Reboot_Shutdown.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorkerLogin_Reboot_Shutdown_DoWork_1);
            // 
            // backgroundWorkerSpeedtest
            // 
            this.backgroundWorkerSpeedtest.WorkerSupportsCancellation = true;
            this.backgroundWorkerSpeedtest.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerSpeedtest_DoWork);
            this.backgroundWorkerSpeedtest.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorkerSpeedtest_RunWorkerCompleted);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(31, 36);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(67, 13);
            this.label35.TabIndex = 10;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(34, 114);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(42, 13);
            this.label36.TabIndex = 19;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(22, 28);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(147, 13);
            this.label38.TabIndex = 23;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(22, 83);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(98, 13);
            this.label39.TabIndex = 24;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(237, 83);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(82, 13);
            this.label40.TabIndex = 25;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(30, 28);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(110, 13);
            this.label34.TabIndex = 9;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(30, 81);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(76, 13);
            this.label30.TabIndex = 10;
            // 
            // backgroundWorkerCOnnectedDeviceAndMacFilter
            // 
            this.backgroundWorkerCOnnectedDeviceAndMacFilter.WorkerSupportsCancellation = true;
            this.backgroundWorkerCOnnectedDeviceAndMacFilter.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerCOnnectedDeviceAndMacFilter_DoWork);
            // 
            // buttonApplyWLAN
            // 
            this.buttonApplyWLAN.Location = new System.Drawing.Point(105, 123);
            this.buttonApplyWLAN.Name = "buttonApplyWLAN";
            this.buttonApplyWLAN.Size = new System.Drawing.Size(71, 28);
            this.buttonApplyWLAN.TabIndex = 51;
            this.buttonApplyWLAN.Text = "Apply";
            this.toolTip1.SetToolTip(this.buttonApplyWLAN, "Save and apply new WLAN setting");
            this.buttonApplyWLAN.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label57.Location = new System.Drawing.Point(27, 98);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(311, 13);
            this.label57.TabIndex = 12;
            // 
            // buttonShutdown
            // 
            this.buttonShutdown.Highlight = true;
            this.buttonShutdown.Location = new System.Drawing.Point(584, 76);
            this.buttonShutdown.Name = "buttonShutdown";
            this.buttonShutdown.Size = new System.Drawing.Size(92, 47);
            this.buttonShutdown.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonShutdown.TabIndex = 42;
            this.buttonShutdown.Text = "Shutdown";
            this.buttonShutdown.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonShutdown.Click += new System.EventHandler(this.ButtonShutdown_Click_1);
            // 
            // buttonReboot
            // 
            this.buttonReboot.Highlight = true;
            this.buttonReboot.Location = new System.Drawing.Point(479, 76);
            this.buttonReboot.Name = "buttonReboot";
            this.buttonReboot.Size = new System.Drawing.Size(92, 47);
            this.buttonReboot.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonReboot.TabIndex = 41;
            this.buttonReboot.Text = "Reboot";
            this.buttonReboot.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonReboot.Click += new System.EventHandler(this.ButtonReboot_Click_1);
            // 
            // buttonLogin
            // 
            this.buttonLogin.Highlight = true;
            this.buttonLogin.Location = new System.Drawing.Point(374, 76);
            this.buttonLogin.Name = "buttonLogin";
            this.buttonLogin.Size = new System.Drawing.Size(92, 47);
            this.buttonLogin.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonLogin.TabIndex = 40;
            this.buttonLogin.Text = "Login";
            this.buttonLogin.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonLogin.Click += new System.EventHandler(this.ButtonLogin_Click_3);
            // 
            // checkBoxRememberUserpass
            // 
            this.checkBoxRememberUserpass.AutoSize = true;
            this.checkBoxRememberUserpass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxRememberUserpass.CustomBackground = true;
            this.checkBoxRememberUserpass.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxRememberUserpass.Location = new System.Drawing.Point(206, 114);
            this.checkBoxRememberUserpass.Name = "checkBoxRememberUserpass";
            this.checkBoxRememberUserpass.Size = new System.Drawing.Size(142, 15);
            this.checkBoxRememberUserpass.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxRememberUserpass.TabIndex = 39;
            this.checkBoxRememberUserpass.Text = "  Remember credential";
            this.checkBoxRememberUserpass.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxRememberUserpass.UseStyleColors = true;
            this.checkBoxRememberUserpass.UseVisualStyleBackColor = false;
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxPassword.CustomBackground = true;
            this.textBoxPassword.Location = new System.Drawing.Point(268, 73);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(89, 23);
            this.textBoxPassword.TabIndex = 37;
            this.textBoxPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxUsername.CustomBackground = true;
            this.textBoxUsername.Location = new System.Drawing.Point(91, 111);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(88, 23);
            this.textBoxUsername.TabIndex = 36;
            this.textBoxUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxIP
            // 
            this.textBoxIP.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxIP.CustomBackground = true;
            this.textBoxIP.Location = new System.Drawing.Point(91, 73);
            this.textBoxIP.Name = "textBoxIP";
            this.textBoxIP.Size = new System.Drawing.Size(89, 23);
            this.textBoxIP.TabIndex = 35;
            this.textBoxIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(203, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 15);
            this.label3.TabIndex = 34;
            this.label3.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(20, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 15);
            this.label2.TabIndex = 33;
            this.label2.Text = "Username:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(20, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 32;
            this.label1.Text = "IP Address:";
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage4);
            this.metroTabControl1.Controls.Add(this.metroTabPage5);
            this.metroTabControl1.Controls.Add(this.metroTabPage9);
            this.metroTabControl1.Controls.Add(this.metroTabPage8);
            this.metroTabControl1.Controls.Add(this.metroTabPage6);
            this.metroTabControl1.Controls.Add(this.metroTabPage7);
            this.metroTabControl1.Enabled = false;
            this.metroTabControl1.FontWeight = MetroFramework.MetroTabControlWeight.Regular;
            this.metroTabControl1.Location = new System.Drawing.Point(16, 159);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 2;
            this.metroTabControl1.Size = new System.Drawing.Size(781, 429);
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroTabControl1.TabIndex = 31;
            this.metroTabControl1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabControl1.UseStyleColors = true;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.BackColor = System.Drawing.Color.Transparent;
            this.metroTabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroTabPage1.Controls.Add(this.groupBox1);
            this.metroTabPage1.Controls.Add(this.textBoxCurrentDownloadRate);
            this.metroTabPage1.Controls.Add(this.textBoxCurrentUploadRate);
            this.metroTabPage1.Controls.Add(this.textBoxCurrentConnectTime);
            this.metroTabPage1.Controls.Add(this.textBoxTotalUpload);
            this.metroTabPage1.Controls.Add(this.textBoxTotalDownload);
            this.metroTabPage1.Controls.Add(this.textBoxMNC);
            this.metroTabPage1.Controls.Add(this.textBoxTotalConnectTime);
            this.metroTabPage1.Controls.Add(this.textBoxModel);
            this.metroTabPage1.Controls.Add(this.textBoxSerialNumber);
            this.metroTabPage1.Controls.Add(this.textBoxImei);
            this.metroTabPage1.Controls.Add(this.textBoxIccid);
            this.metroTabPage1.Controls.Add(this.textBoxMsisdn);
            this.metroTabPage1.Controls.Add(this.textBoxHardwareVersion);
            this.metroTabPage1.Controls.Add(this.textBoxSoftwareVersion);
            this.metroTabPage1.Controls.Add(this.textBoxMacAddress);
            this.metroTabPage1.Controls.Add(this.textBoxWorkmode);
            this.metroTabPage1.Controls.Add(this.textBoxNetworkProvider);
            this.metroTabPage1.Controls.Add(this.textBoxsimLock);
            this.metroTabPage1.Controls.Add(this.textBoxWebuiVersion);
            this.metroTabPage1.Controls.Add(this.linkLabel2);
            this.metroTabPage1.Controls.Add(this.label21);
            this.metroTabPage1.Controls.Add(this.label15);
            this.metroTabPage1.Controls.Add(this.label16);
            this.metroTabPage1.Controls.Add(this.label17);
            this.metroTabPage1.Controls.Add(this.label18);
            this.metroTabPage1.Controls.Add(this.label19);
            this.metroTabPage1.Controls.Add(this.label20);
            this.metroTabPage1.Controls.Add(this.label31);
            this.metroTabPage1.Controls.Add(this.label14);
            this.metroTabPage1.Controls.Add(this.label4);
            this.metroTabPage1.Controls.Add(this.label13);
            this.metroTabPage1.Controls.Add(this.label12);
            this.metroTabPage1.Controls.Add(this.label11);
            this.metroTabPage1.Controls.Add(this.label10);
            this.metroTabPage1.Controls.Add(this.label9);
            this.metroTabPage1.Controls.Add(this.label8);
            this.metroTabPage1.Controls.Add(this.label7);
            this.metroTabPage1.Controls.Add(this.label6);
            this.metroTabPage1.Controls.Add(this.label5);
            this.metroTabPage1.Font = new System.Drawing.Font("Segoe UI Semilight", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.metroTabPage1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(773, 390);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Device Info";
            this.metroTabPage1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.metroButtonSIGNALMONITOR);
            this.groupBox1.Controls.Add(this.textBoxRSSI);
            this.groupBox1.Controls.Add(this.textBoxSINR);
            this.groupBox1.Controls.Add(this.textBoxRSRQ);
            this.groupBox1.Controls.Add(this.textBoxRSRP);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox1.Location = new System.Drawing.Point(398, 231);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(308, 125);
            this.groupBox1.TabIndex = 90;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Signal Monitoring";
            // 
            // metroButtonSIGNALMONITOR
            // 
            this.metroButtonSIGNALMONITOR.Enabled = false;
            this.metroButtonSIGNALMONITOR.Highlight = true;
            this.metroButtonSIGNALMONITOR.Location = new System.Drawing.Point(101, 89);
            this.metroButtonSIGNALMONITOR.Name = "metroButtonSIGNALMONITOR";
            this.metroButtonSIGNALMONITOR.Size = new System.Drawing.Size(92, 24);
            this.metroButtonSIGNALMONITOR.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroButtonSIGNALMONITOR.TabIndex = 91;
            this.metroButtonSIGNALMONITOR.Text = "Signal Monitor";
            this.metroButtonSIGNALMONITOR.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButtonSIGNALMONITOR.Click += new System.EventHandler(this.MetroButton1_Click_1);
            // 
            // textBoxRSSI
            // 
            this.textBoxRSSI.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxRSSI.CustomBackground = true;
            this.textBoxRSSI.Location = new System.Drawing.Point(216, 25);
            this.textBoxRSSI.Name = "textBoxRSSI";
            this.textBoxRSSI.ReadOnly = true;
            this.textBoxRSSI.Size = new System.Drawing.Size(54, 23);
            this.textBoxRSSI.TabIndex = 90;
            this.textBoxRSSI.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxSINR
            // 
            this.textBoxSINR.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxSINR.CustomBackground = true;
            this.textBoxSINR.Location = new System.Drawing.Point(216, 57);
            this.textBoxSINR.Name = "textBoxSINR";
            this.textBoxSINR.ReadOnly = true;
            this.textBoxSINR.Size = new System.Drawing.Size(54, 23);
            this.textBoxSINR.TabIndex = 89;
            this.textBoxSINR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxRSRQ
            // 
            this.textBoxRSRQ.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxRSRQ.CustomBackground = true;
            this.textBoxRSRQ.Location = new System.Drawing.Point(84, 25);
            this.textBoxRSRQ.Name = "textBoxRSRQ";
            this.textBoxRSRQ.ReadOnly = true;
            this.textBoxRSRQ.Size = new System.Drawing.Size(54, 23);
            this.textBoxRSRQ.TabIndex = 88;
            this.textBoxRSRQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxRSRP
            // 
            this.textBoxRSRP.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxRSRP.CustomBackground = true;
            this.textBoxRSRP.Location = new System.Drawing.Point(84, 57);
            this.textBoxRSRP.Name = "textBoxRSRP";
            this.textBoxRSRP.ReadOnly = true;
            this.textBoxRSRP.Size = new System.Drawing.Size(54, 23);
            this.textBoxRSRP.TabIndex = 87;
            this.textBoxRSRP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label25.Location = new System.Drawing.Point(166, 61);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 15);
            this.label25.TabIndex = 86;
            this.label25.Text = "SINR:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label24.Location = new System.Drawing.Point(166, 29);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 15);
            this.label24.TabIndex = 85;
            this.label24.Text = "RSSI:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label23.Location = new System.Drawing.Point(39, 61);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(37, 15);
            this.label23.TabIndex = 84;
            this.label23.Text = "RSRP:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label22.Location = new System.Drawing.Point(39, 29);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(39, 15);
            this.label22.TabIndex = 83;
            this.label22.Text = "RSRQ:";
            // 
            // textBoxCurrentDownloadRate
            // 
            this.textBoxCurrentDownloadRate.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxCurrentDownloadRate.CustomBackground = true;
            this.textBoxCurrentDownloadRate.Location = new System.Drawing.Point(622, 28);
            this.textBoxCurrentDownloadRate.Name = "textBoxCurrentDownloadRate";
            this.textBoxCurrentDownloadRate.ReadOnly = true;
            this.textBoxCurrentDownloadRate.Size = new System.Drawing.Size(84, 23);
            this.textBoxCurrentDownloadRate.TabIndex = 89;
            this.textBoxCurrentDownloadRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxCurrentUploadRate
            // 
            this.textBoxCurrentUploadRate.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxCurrentUploadRate.CustomBackground = true;
            this.textBoxCurrentUploadRate.Location = new System.Drawing.Point(622, 56);
            this.textBoxCurrentUploadRate.Name = "textBoxCurrentUploadRate";
            this.textBoxCurrentUploadRate.ReadOnly = true;
            this.textBoxCurrentUploadRate.Size = new System.Drawing.Size(84, 23);
            this.textBoxCurrentUploadRate.TabIndex = 88;
            this.textBoxCurrentUploadRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxCurrentConnectTime
            // 
            this.textBoxCurrentConnectTime.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxCurrentConnectTime.CustomBackground = true;
            this.textBoxCurrentConnectTime.Location = new System.Drawing.Point(622, 84);
            this.textBoxCurrentConnectTime.Name = "textBoxCurrentConnectTime";
            this.textBoxCurrentConnectTime.ReadOnly = true;
            this.textBoxCurrentConnectTime.Size = new System.Drawing.Size(84, 23);
            this.textBoxCurrentConnectTime.TabIndex = 87;
            this.textBoxCurrentConnectTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTotalUpload
            // 
            this.textBoxTotalUpload.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxTotalUpload.CustomBackground = true;
            this.textBoxTotalUpload.Location = new System.Drawing.Point(622, 112);
            this.textBoxTotalUpload.Name = "textBoxTotalUpload";
            this.textBoxTotalUpload.ReadOnly = true;
            this.textBoxTotalUpload.Size = new System.Drawing.Size(84, 23);
            this.textBoxTotalUpload.TabIndex = 86;
            this.textBoxTotalUpload.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTotalDownload
            // 
            this.textBoxTotalDownload.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxTotalDownload.CustomBackground = true;
            this.textBoxTotalDownload.Location = new System.Drawing.Point(622, 140);
            this.textBoxTotalDownload.Name = "textBoxTotalDownload";
            this.textBoxTotalDownload.ReadOnly = true;
            this.textBoxTotalDownload.Size = new System.Drawing.Size(84, 23);
            this.textBoxTotalDownload.TabIndex = 85;
            this.textBoxTotalDownload.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxMNC
            // 
            this.textBoxMNC.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxMNC.CustomBackground = true;
            this.textBoxMNC.Location = new System.Drawing.Point(622, 196);
            this.textBoxMNC.Name = "textBoxMNC";
            this.textBoxMNC.ReadOnly = true;
            this.textBoxMNC.Size = new System.Drawing.Size(84, 23);
            this.textBoxMNC.TabIndex = 83;
            this.textBoxMNC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTotalConnectTime
            // 
            this.textBoxTotalConnectTime.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxTotalConnectTime.CustomBackground = true;
            this.textBoxTotalConnectTime.Location = new System.Drawing.Point(622, 168);
            this.textBoxTotalConnectTime.Name = "textBoxTotalConnectTime";
            this.textBoxTotalConnectTime.ReadOnly = true;
            this.textBoxTotalConnectTime.Size = new System.Drawing.Size(84, 23);
            this.textBoxTotalConnectTime.TabIndex = 84;
            this.textBoxTotalConnectTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxModel
            // 
            this.textBoxModel.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxModel.CustomBackground = true;
            this.textBoxModel.Location = new System.Drawing.Point(195, 28);
            this.textBoxModel.Name = "textBoxModel";
            this.textBoxModel.ReadOnly = true;
            this.textBoxModel.Size = new System.Drawing.Size(134, 23);
            this.textBoxModel.TabIndex = 78;
            this.textBoxModel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxSerialNumber
            // 
            this.textBoxSerialNumber.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxSerialNumber.CustomBackground = true;
            this.textBoxSerialNumber.Location = new System.Drawing.Point(195, 56);
            this.textBoxSerialNumber.Name = "textBoxSerialNumber";
            this.textBoxSerialNumber.ReadOnly = true;
            this.textBoxSerialNumber.Size = new System.Drawing.Size(134, 23);
            this.textBoxSerialNumber.TabIndex = 77;
            this.textBoxSerialNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxImei
            // 
            this.textBoxImei.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxImei.CustomBackground = true;
            this.textBoxImei.Location = new System.Drawing.Point(195, 84);
            this.textBoxImei.Name = "textBoxImei";
            this.textBoxImei.ReadOnly = true;
            this.textBoxImei.Size = new System.Drawing.Size(134, 23);
            this.textBoxImei.TabIndex = 76;
            this.textBoxImei.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxIccid
            // 
            this.textBoxIccid.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxIccid.CustomBackground = true;
            this.textBoxIccid.Location = new System.Drawing.Point(195, 112);
            this.textBoxIccid.Name = "textBoxIccid";
            this.textBoxIccid.ReadOnly = true;
            this.textBoxIccid.Size = new System.Drawing.Size(134, 23);
            this.textBoxIccid.TabIndex = 75;
            this.textBoxIccid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxMsisdn
            // 
            this.textBoxMsisdn.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxMsisdn.CustomBackground = true;
            this.textBoxMsisdn.Location = new System.Drawing.Point(195, 140);
            this.textBoxMsisdn.Name = "textBoxMsisdn";
            this.textBoxMsisdn.ReadOnly = true;
            this.textBoxMsisdn.Size = new System.Drawing.Size(134, 23);
            this.textBoxMsisdn.TabIndex = 74;
            this.textBoxMsisdn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxHardwareVersion
            // 
            this.textBoxHardwareVersion.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxHardwareVersion.CustomBackground = true;
            this.textBoxHardwareVersion.Location = new System.Drawing.Point(195, 168);
            this.textBoxHardwareVersion.Name = "textBoxHardwareVersion";
            this.textBoxHardwareVersion.ReadOnly = true;
            this.textBoxHardwareVersion.Size = new System.Drawing.Size(134, 23);
            this.textBoxHardwareVersion.TabIndex = 73;
            this.textBoxHardwareVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxSoftwareVersion
            // 
            this.textBoxSoftwareVersion.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxSoftwareVersion.CustomBackground = true;
            this.textBoxSoftwareVersion.Location = new System.Drawing.Point(195, 196);
            this.textBoxSoftwareVersion.Name = "textBoxSoftwareVersion";
            this.textBoxSoftwareVersion.ReadOnly = true;
            this.textBoxSoftwareVersion.Size = new System.Drawing.Size(134, 23);
            this.textBoxSoftwareVersion.TabIndex = 72;
            this.textBoxSoftwareVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxMacAddress
            // 
            this.textBoxMacAddress.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxMacAddress.CustomBackground = true;
            this.textBoxMacAddress.Location = new System.Drawing.Point(195, 252);
            this.textBoxMacAddress.Name = "textBoxMacAddress";
            this.textBoxMacAddress.ReadOnly = true;
            this.textBoxMacAddress.Size = new System.Drawing.Size(134, 23);
            this.textBoxMacAddress.TabIndex = 71;
            this.textBoxMacAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxWorkmode
            // 
            this.textBoxWorkmode.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxWorkmode.CustomBackground = true;
            this.textBoxWorkmode.Location = new System.Drawing.Point(195, 280);
            this.textBoxWorkmode.Name = "textBoxWorkmode";
            this.textBoxWorkmode.ReadOnly = true;
            this.textBoxWorkmode.Size = new System.Drawing.Size(134, 23);
            this.textBoxWorkmode.TabIndex = 70;
            this.textBoxWorkmode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxNetworkProvider
            // 
            this.textBoxNetworkProvider.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxNetworkProvider.CustomBackground = true;
            this.textBoxNetworkProvider.Location = new System.Drawing.Point(195, 308);
            this.textBoxNetworkProvider.Name = "textBoxNetworkProvider";
            this.textBoxNetworkProvider.ReadOnly = true;
            this.textBoxNetworkProvider.Size = new System.Drawing.Size(134, 23);
            this.textBoxNetworkProvider.TabIndex = 69;
            this.textBoxNetworkProvider.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxsimLock
            // 
            this.textBoxsimLock.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxsimLock.CustomBackground = true;
            this.textBoxsimLock.Location = new System.Drawing.Point(195, 336);
            this.textBoxsimLock.Name = "textBoxsimLock";
            this.textBoxsimLock.ReadOnly = true;
            this.textBoxsimLock.Size = new System.Drawing.Size(134, 23);
            this.textBoxsimLock.TabIndex = 68;
            this.textBoxsimLock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxWebuiVersion
            // 
            this.textBoxWebuiVersion.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxWebuiVersion.CustomBackground = true;
            this.textBoxWebuiVersion.Location = new System.Drawing.Point(195, 224);
            this.textBoxWebuiVersion.Name = "textBoxWebuiVersion";
            this.textBoxWebuiVersion.ReadOnly = true;
            this.textBoxWebuiVersion.Size = new System.Drawing.Size(134, 23);
            this.textBoxWebuiVersion.TabIndex = 67;
            this.textBoxWebuiVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.linkLabel2.Location = new System.Drawing.Point(525, 200);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(47, 17);
            this.linkLabel2.TabIndex = 66;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Search";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel2_LinkClicked);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label21.Location = new System.Drawing.Point(395, 200);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 17);
            this.label21.TabIndex = 57;
            this.label21.Text = "MCC-MNC";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label15.Location = new System.Drawing.Point(395, 32);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(147, 17);
            this.label15.TabIndex = 52;
            this.label15.Text = "Current Download Rate:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label16.Location = new System.Drawing.Point(395, 172);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(196, 17);
            this.label16.TabIndex = 55;
            this.label16.Text = "Total Connect Time (HH:MM:SS):";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label17.Location = new System.Drawing.Point(395, 144);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(102, 17);
            this.label17.TabIndex = 54;
            this.label17.Text = "Total Download:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label18.Location = new System.Drawing.Point(395, 116);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(86, 17);
            this.label18.TabIndex = 53;
            this.label18.Text = "Total Upload:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label19.Location = new System.Drawing.Point(395, 88);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(211, 17);
            this.label19.TabIndex = 51;
            this.label19.Text = "Current Connect Time (HH:MM:SS):";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label20.Location = new System.Drawing.Point(395, 60);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(131, 17);
            this.label20.TabIndex = 50;
            this.label20.Text = "Current Upload Rate:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label31.Location = new System.Drawing.Point(64, 341);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(94, 17);
            this.label31.TabIndex = 43;
            this.label31.Text = "Simlock Status:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label14.Location = new System.Drawing.Point(64, 312);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(113, 17);
            this.label14.TabIndex = 41;
            this.label14.Text = "Network Provider:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(64, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 31;
            this.label4.Text = "Model:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label13.Location = new System.Drawing.Point(64, 284);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 17);
            this.label13.TabIndex = 40;
            this.label13.Text = "Workmode:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label12.Location = new System.Drawing.Point(64, 256);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 17);
            this.label12.TabIndex = 39;
            this.label12.Text = "Mac Address:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label11.Location = new System.Drawing.Point(64, 228);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 17);
            this.label11.TabIndex = 38;
            this.label11.Text = "Webui Version:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label10.Location = new System.Drawing.Point(64, 200);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 17);
            this.label10.TabIndex = 37;
            this.label10.Text = "Software Version:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(64, 172);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(115, 17);
            this.label9.TabIndex = 34;
            this.label9.Text = "Hardware Version:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label8.Location = new System.Drawing.Point(64, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 17);
            this.label8.TabIndex = 33;
            this.label8.Text = "Msisdn:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(64, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 17);
            this.label7.TabIndex = 29;
            this.label7.Text = "Iccid:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(64, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 17);
            this.label6.TabIndex = 27;
            this.label6.Text = "Imei:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(64, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 17);
            this.label5.TabIndex = 25;
            this.label5.Text = "Serial Number:";
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroTabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroTabPage3.Controls.Add(this.buttonRestore);
            this.metroTabPage3.Controls.Add(this.comboBoxDeviceMode);
            this.metroTabPage3.Controls.Add(this.label26);
            this.metroTabPage3.Controls.Add(this.groupBox10);
            this.metroTabPage3.Controls.Add(this.groupBox9);
            this.metroTabPage3.Controls.Add(this.label55);
            this.metroTabPage3.Controls.Add(this.groupBox7);
            this.metroTabPage3.CustomBackground = true;
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(773, 390);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "Device Setting";
            this.metroTabPage3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            // 
            // buttonRestore
            // 
            this.buttonRestore.Highlight = true;
            this.buttonRestore.Location = new System.Drawing.Point(533, 309);
            this.buttonRestore.Name = "buttonRestore";
            this.buttonRestore.Size = new System.Drawing.Size(172, 36);
            this.buttonRestore.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonRestore.TabIndex = 49;
            this.buttonRestore.Text = "Restore default setting";
            this.buttonRestore.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonRestore.Click += new System.EventHandler(this.ButtonRestore_Click);
            // 
            // comboBoxDeviceMode
            // 
            this.comboBoxDeviceMode.FormattingEnabled = true;
            this.comboBoxDeviceMode.ItemHeight = 23;
            this.comboBoxDeviceMode.Items.AddRange(new object[] {
            "Project Mode",
            "Debug Mode"});
            this.comboBoxDeviceMode.Location = new System.Drawing.Point(602, 221);
            this.comboBoxDeviceMode.Name = "comboBoxDeviceMode";
            this.comboBoxDeviceMode.Size = new System.Drawing.Size(130, 29);
            this.comboBoxDeviceMode.Style = MetroFramework.MetroColorStyle.Lime;
            this.comboBoxDeviceMode.TabIndex = 42;
            this.comboBoxDeviceMode.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.comboBoxDeviceMode.SelectedIndexChanged += new System.EventHandler(this.ComboBoxDeviceMode_SelectedIndexChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.DarkGray;
            this.label26.Location = new System.Drawing.Point(513, 255);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(160, 30);
            this.label26.TabIndex = 41;
            this.label26.Text = "Project mode - Normal mode\r\nDebug mode -  Debug/NDIS ";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.Transparent;
            this.groupBox10.Controls.Add(this.textBoxSIP);
            this.groupBox10.Controls.Add(this.textBoxDMZ);
            this.groupBox10.Controls.Add(this.checkBoxDMZ);
            this.groupBox10.Controls.Add(this.checkBoxNAT);
            this.groupBox10.Controls.Add(this.checkBoxSIP);
            this.groupBox10.Controls.Add(this.checkBoxUPnP);
            this.groupBox10.Controls.Add(this.checkBoxMobileConnection);
            this.groupBox10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox10.Location = new System.Drawing.Point(428, 35);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(304, 159);
            this.groupBox10.TabIndex = 40;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Security";
            // 
            // textBoxSIP
            // 
            this.textBoxSIP.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxSIP.CustomBackground = true;
            this.textBoxSIP.Location = new System.Drawing.Point(154, 117);
            this.textBoxSIP.Name = "textBoxSIP";
            this.textBoxSIP.Size = new System.Drawing.Size(89, 23);
            this.textBoxSIP.TabIndex = 46;
            this.textBoxSIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxDMZ
            // 
            this.textBoxDMZ.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxDMZ.CustomBackground = true;
            this.textBoxDMZ.Location = new System.Drawing.Point(154, 90);
            this.textBoxDMZ.Name = "textBoxDMZ";
            this.textBoxDMZ.Size = new System.Drawing.Size(89, 23);
            this.textBoxDMZ.TabIndex = 45;
            this.textBoxDMZ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // checkBoxDMZ
            // 
            this.checkBoxDMZ.AutoSize = true;
            this.checkBoxDMZ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxDMZ.CustomBackground = true;
            this.checkBoxDMZ.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxDMZ.Location = new System.Drawing.Point(61, 96);
            this.checkBoxDMZ.Name = "checkBoxDMZ";
            this.checkBoxDMZ.Size = new System.Drawing.Size(49, 15);
            this.checkBoxDMZ.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxDMZ.TabIndex = 44;
            this.checkBoxDMZ.Text = "DMZ";
            this.checkBoxDMZ.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxDMZ.UseStyleColors = true;
            this.checkBoxDMZ.UseVisualStyleBackColor = false;
            this.checkBoxDMZ.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckBoxDMZ_MouseClick);
            // 
            // checkBoxNAT
            // 
            this.checkBoxNAT.AutoSize = true;
            this.checkBoxNAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxNAT.CustomBackground = true;
            this.checkBoxNAT.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxNAT.Location = new System.Drawing.Point(61, 73);
            this.checkBoxNAT.Name = "checkBoxNAT";
            this.checkBoxNAT.Size = new System.Drawing.Size(45, 15);
            this.checkBoxNAT.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxNAT.TabIndex = 43;
            this.checkBoxNAT.Text = "NAT";
            this.checkBoxNAT.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxNAT.UseStyleColors = true;
            this.checkBoxNAT.UseVisualStyleBackColor = false;
            this.checkBoxNAT.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckBoxNAT_MouseClick);
            // 
            // checkBoxSIP
            // 
            this.checkBoxSIP.AutoSize = true;
            this.checkBoxSIP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxSIP.CustomBackground = true;
            this.checkBoxSIP.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxSIP.Location = new System.Drawing.Point(61, 119);
            this.checkBoxSIP.Name = "checkBoxSIP";
            this.checkBoxSIP.Size = new System.Drawing.Size(64, 15);
            this.checkBoxSIP.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxSIP.TabIndex = 42;
            this.checkBoxSIP.Text = "SIP ALG";
            this.checkBoxSIP.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxSIP.UseStyleColors = true;
            this.checkBoxSIP.UseVisualStyleBackColor = false;
            this.checkBoxSIP.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckBoxSIP_MouseClick);
            // 
            // checkBoxUPnP
            // 
            this.checkBoxUPnP.AutoSize = true;
            this.checkBoxUPnP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxUPnP.CustomBackground = true;
            this.checkBoxUPnP.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxUPnP.Location = new System.Drawing.Point(61, 50);
            this.checkBoxUPnP.Name = "checkBoxUPnP";
            this.checkBoxUPnP.Size = new System.Drawing.Size(52, 15);
            this.checkBoxUPnP.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxUPnP.TabIndex = 41;
            this.checkBoxUPnP.Text = "UPnP";
            this.checkBoxUPnP.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxUPnP.UseStyleColors = true;
            this.checkBoxUPnP.UseVisualStyleBackColor = false;
            this.checkBoxUPnP.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckBoxUPnP_MouseClick);
            // 
            // checkBoxMobileConnection
            // 
            this.checkBoxMobileConnection.AutoSize = true;
            this.checkBoxMobileConnection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxMobileConnection.CustomBackground = true;
            this.checkBoxMobileConnection.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxMobileConnection.Location = new System.Drawing.Point(61, 27);
            this.checkBoxMobileConnection.Name = "checkBoxMobileConnection";
            this.checkBoxMobileConnection.Size = new System.Drawing.Size(125, 15);
            this.checkBoxMobileConnection.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxMobileConnection.TabIndex = 40;
            this.checkBoxMobileConnection.Text = "Mobile Connection";
            this.checkBoxMobileConnection.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxMobileConnection.UseStyleColors = true;
            this.checkBoxMobileConnection.UseVisualStyleBackColor = false;
            this.checkBoxMobileConnection.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckBoxMobileConnection_MouseClick);
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.Transparent;
            this.groupBox9.Controls.Add(this.buttonSaveDevicePW);
            this.groupBox9.Controls.Add(this.textBoxNewPW);
            this.groupBox9.Controls.Add(this.textBoxCurrentPW);
            this.groupBox9.Controls.Add(this.label28);
            this.groupBox9.Controls.Add(this.label27);
            this.groupBox9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox9.Location = new System.Drawing.Point(39, 35);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(336, 159);
            this.groupBox9.TabIndex = 39;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Device Password";
            // 
            // buttonSaveDevicePW
            // 
            this.buttonSaveDevicePW.Highlight = true;
            this.buttonSaveDevicePW.Location = new System.Drawing.Point(118, 111);
            this.buttonSaveDevicePW.Name = "buttonSaveDevicePW";
            this.buttonSaveDevicePW.Size = new System.Drawing.Size(100, 23);
            this.buttonSaveDevicePW.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonSaveDevicePW.TabIndex = 48;
            this.buttonSaveDevicePW.Text = "Apply";
            this.buttonSaveDevicePW.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonSaveDevicePW.Click += new System.EventHandler(this.ButtonSaveDevicePW_Click);
            // 
            // textBoxNewPW
            // 
            this.textBoxNewPW.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxNewPW.CustomBackground = true;
            this.textBoxNewPW.Location = new System.Drawing.Point(166, 74);
            this.textBoxNewPW.Name = "textBoxNewPW";
            this.textBoxNewPW.Size = new System.Drawing.Size(119, 23);
            this.textBoxNewPW.TabIndex = 47;
            this.textBoxNewPW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxCurrentPW
            // 
            this.textBoxCurrentPW.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxCurrentPW.CustomBackground = true;
            this.textBoxCurrentPW.Location = new System.Drawing.Point(166, 33);
            this.textBoxCurrentPW.Name = "textBoxCurrentPW";
            this.textBoxCurrentPW.Size = new System.Drawing.Size(119, 23);
            this.textBoxCurrentPW.TabIndex = 46;
            this.textBoxCurrentPW.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label28.Location = new System.Drawing.Point(52, 77);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(87, 15);
            this.label28.TabIndex = 7;
            this.label28.Text = "New Password:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label27.Location = new System.Drawing.Point(52, 36);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 15);
            this.label27.TabIndex = 6;
            this.label27.Text = "Current Password:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.Transparent;
            this.label55.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label55.Location = new System.Drawing.Point(513, 227);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(79, 15);
            this.label55.TabIndex = 38;
            this.label55.Text = "Device Mode:";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Transparent;
            this.groupBox7.Controls.Add(this.checkBoxFW3);
            this.groupBox7.Controls.Add(this.checkBoxFW2);
            this.groupBox7.Controls.Add(this.checkBoxFW1);
            this.groupBox7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox7.Location = new System.Drawing.Point(39, 216);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(453, 137);
            this.groupBox7.TabIndex = 35;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Firmware Update";
            // 
            // checkBoxFW3
            // 
            this.checkBoxFW3.AutoSize = true;
            this.checkBoxFW3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxFW3.CustomBackground = true;
            this.checkBoxFW3.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxFW3.Location = new System.Drawing.Point(36, 93);
            this.checkBoxFW3.Name = "checkBoxFW3";
            this.checkBoxFW3.Size = new System.Drawing.Size(259, 15);
            this.checkBoxFW3.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxFW3.TabIndex = 43;
            this.checkBoxFW3.Text = "Auto-download (auto-update after a restart) ";
            this.checkBoxFW3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxFW3.UseStyleColors = true;
            this.checkBoxFW3.UseVisualStyleBackColor = false;
            this.checkBoxFW3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckBoxFW3_MouseClick);
            // 
            // checkBoxFW2
            // 
            this.checkBoxFW2.AutoSize = true;
            this.checkBoxFW2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxFW2.CustomBackground = true;
            this.checkBoxFW2.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxFW2.Location = new System.Drawing.Point(36, 64);
            this.checkBoxFW2.Name = "checkBoxFW2";
            this.checkBoxFW2.Size = new System.Drawing.Size(380, 15);
            this.checkBoxFW2.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxFW2.TabIndex = 42;
            this.checkBoxFW2.Text = "Allow device to automatically install critical updates (force update). ";
            this.checkBoxFW2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxFW2.UseStyleColors = true;
            this.checkBoxFW2.UseVisualStyleBackColor = false;
            this.checkBoxFW2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckBoxFW2_MouseClick);
            // 
            // checkBoxFW1
            // 
            this.checkBoxFW1.AutoSize = true;
            this.checkBoxFW1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxFW1.CustomBackground = true;
            this.checkBoxFW1.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxFW1.Location = new System.Drawing.Point(36, 32);
            this.checkBoxFW1.Name = "checkBoxFW1";
            this.checkBoxFW1.Size = new System.Drawing.Size(251, 15);
            this.checkBoxFW1.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxFW1.TabIndex = 41;
            this.checkBoxFW1.Text = "Allow device to update without logging in. ";
            this.checkBoxFW1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxFW1.UseStyleColors = true;
            this.checkBoxFW1.UseVisualStyleBackColor = false;
            this.checkBoxFW1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckBoxFW1_MouseClick);
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroTabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroTabPage2.Controls.Add(this.buttonRefreshConnectedClient);
            this.metroTabPage2.Controls.Add(this.groupBox11);
            this.metroTabPage2.Controls.Add(this.listView1);
            this.metroTabPage2.CustomBackground = true;
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(773, 390);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Device Management";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            // 
            // buttonRefreshConnectedClient
            // 
            this.buttonRefreshConnectedClient.Highlight = true;
            this.buttonRefreshConnectedClient.Location = new System.Drawing.Point(22, 200);
            this.buttonRefreshConnectedClient.Name = "buttonRefreshConnectedClient";
            this.buttonRefreshConnectedClient.Size = new System.Drawing.Size(100, 23);
            this.buttonRefreshConnectedClient.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonRefreshConnectedClient.TabIndex = 41;
            this.buttonRefreshConnectedClient.Text = "Refresh list";
            this.buttonRefreshConnectedClient.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonRefreshConnectedClient.Click += new System.EventHandler(this.MetroButton1_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.btnRefreshMAC);
            this.groupBox11.Controls.Add(this.buttonUnblockAll);
            this.groupBox11.Controls.Add(this.buttonBlockDevice);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC0);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC1);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC2);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC3);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC4);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC5);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC9);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC6);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC8);
            this.groupBox11.Controls.Add(this.textBoxBlockMAC7);
            this.groupBox11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox11.Location = new System.Drawing.Point(22, 238);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(727, 132);
            this.groupBox11.TabIndex = 8;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Manage MAC Address";
            // 
            // buttonUnblockAll
            // 
            this.buttonUnblockAll.Highlight = true;
            this.buttonUnblockAll.Location = new System.Drawing.Point(372, 96);
            this.buttonUnblockAll.Name = "buttonUnblockAll";
            this.buttonUnblockAll.Size = new System.Drawing.Size(100, 23);
            this.buttonUnblockAll.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonUnblockAll.TabIndex = 90;
            this.buttonUnblockAll.Text = "Unblock all";
            this.buttonUnblockAll.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonUnblockAll.Click += new System.EventHandler(this.ButtonUnblockAll_Click);
            // 
            // buttonBlockDevice
            // 
            this.buttonBlockDevice.Highlight = true;
            this.buttonBlockDevice.Location = new System.Drawing.Point(255, 96);
            this.buttonBlockDevice.Name = "buttonBlockDevice";
            this.buttonBlockDevice.Size = new System.Drawing.Size(100, 23);
            this.buttonBlockDevice.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonBlockDevice.TabIndex = 89;
            this.buttonBlockDevice.Text = "Block device";
            this.buttonBlockDevice.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonBlockDevice.Click += new System.EventHandler(this.ButtonBlockDevice_Click);
            // 
            // textBoxBlockMAC0
            // 
            this.textBoxBlockMAC0.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC0.CustomBackground = true;
            this.textBoxBlockMAC0.Location = new System.Drawing.Point(63, 27);
            this.textBoxBlockMAC0.Name = "textBoxBlockMAC0";
            this.textBoxBlockMAC0.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC0.TabIndex = 88;
            this.textBoxBlockMAC0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBlockMAC1
            // 
            this.textBoxBlockMAC1.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC1.CustomBackground = true;
            this.textBoxBlockMAC1.Location = new System.Drawing.Point(188, 26);
            this.textBoxBlockMAC1.Name = "textBoxBlockMAC1";
            this.textBoxBlockMAC1.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC1.TabIndex = 87;
            this.textBoxBlockMAC1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBlockMAC2
            // 
            this.textBoxBlockMAC2.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC2.CustomBackground = true;
            this.textBoxBlockMAC2.Location = new System.Drawing.Point(313, 26);
            this.textBoxBlockMAC2.Name = "textBoxBlockMAC2";
            this.textBoxBlockMAC2.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC2.TabIndex = 86;
            this.textBoxBlockMAC2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBlockMAC3
            // 
            this.textBoxBlockMAC3.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC3.CustomBackground = true;
            this.textBoxBlockMAC3.Location = new System.Drawing.Point(438, 27);
            this.textBoxBlockMAC3.Name = "textBoxBlockMAC3";
            this.textBoxBlockMAC3.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC3.TabIndex = 85;
            this.textBoxBlockMAC3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBlockMAC4
            // 
            this.textBoxBlockMAC4.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC4.CustomBackground = true;
            this.textBoxBlockMAC4.Location = new System.Drawing.Point(563, 27);
            this.textBoxBlockMAC4.Name = "textBoxBlockMAC4";
            this.textBoxBlockMAC4.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC4.TabIndex = 84;
            this.textBoxBlockMAC4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBlockMAC5
            // 
            this.textBoxBlockMAC5.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC5.CustomBackground = true;
            this.textBoxBlockMAC5.Location = new System.Drawing.Point(63, 64);
            this.textBoxBlockMAC5.Name = "textBoxBlockMAC5";
            this.textBoxBlockMAC5.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC5.TabIndex = 83;
            this.textBoxBlockMAC5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBlockMAC9
            // 
            this.textBoxBlockMAC9.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC9.CustomBackground = true;
            this.textBoxBlockMAC9.Location = new System.Drawing.Point(563, 64);
            this.textBoxBlockMAC9.Name = "textBoxBlockMAC9";
            this.textBoxBlockMAC9.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC9.TabIndex = 82;
            this.textBoxBlockMAC9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBlockMAC6
            // 
            this.textBoxBlockMAC6.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC6.CustomBackground = true;
            this.textBoxBlockMAC6.Location = new System.Drawing.Point(188, 64);
            this.textBoxBlockMAC6.Name = "textBoxBlockMAC6";
            this.textBoxBlockMAC6.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC6.TabIndex = 81;
            this.textBoxBlockMAC6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBlockMAC8
            // 
            this.textBoxBlockMAC8.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC8.CustomBackground = true;
            this.textBoxBlockMAC8.Location = new System.Drawing.Point(438, 64);
            this.textBoxBlockMAC8.Name = "textBoxBlockMAC8";
            this.textBoxBlockMAC8.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC8.TabIndex = 80;
            this.textBoxBlockMAC8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBlockMAC7
            // 
            this.textBoxBlockMAC7.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxBlockMAC7.CustomBackground = true;
            this.textBoxBlockMAC7.Location = new System.Drawing.Point(313, 64);
            this.textBoxBlockMAC7.Name = "textBoxBlockMAC7";
            this.textBoxBlockMAC7.Size = new System.Drawing.Size(100, 23);
            this.textBoxBlockMAC7.TabIndex = 79;
            this.textBoxBlockMAC7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.DarkGray;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(22, 19);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(727, 175);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ListView1_MouseClick);
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroTabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroTabPage4.Controls.Add(this.groupBox13);
            this.metroTabPage4.Controls.Add(this.groupBox12);
            this.metroTabPage4.Controls.Add(this.groupBox5);
            this.metroTabPage4.Controls.Add(this.groupBox6);
            this.metroTabPage4.CustomBackground = true;
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Size = new System.Drawing.Size(773, 390);
            this.metroTabPage4.TabIndex = 3;
            this.metroTabPage4.Text = "WLAN Tools";
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.buttonAuto);
            this.groupBox13.Controls.Add(this.button4G);
            this.groupBox13.Controls.Add(this.button3G);
            this.groupBox13.Controls.Add(this.button2G);
            this.groupBox13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox13.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox13.Location = new System.Drawing.Point(37, 268);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(327, 91);
            this.groupBox13.TabIndex = 50;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "LTE Band Quick Switch";
            // 
            // buttonAuto
            // 
            this.buttonAuto.Highlight = true;
            this.buttonAuto.Location = new System.Drawing.Point(246, 36);
            this.buttonAuto.Name = "buttonAuto";
            this.buttonAuto.Size = new System.Drawing.Size(51, 27);
            this.buttonAuto.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonAuto.TabIndex = 44;
            this.buttonAuto.Text = "Auto";
            this.buttonAuto.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonAuto.Click += new System.EventHandler(this.ButtonAuto_Click);
            // 
            // button4G
            // 
            this.button4G.Highlight = true;
            this.button4G.Location = new System.Drawing.Point(174, 36);
            this.button4G.Name = "button4G";
            this.button4G.Size = new System.Drawing.Size(51, 27);
            this.button4G.Style = MetroFramework.MetroColorStyle.Lime;
            this.button4G.TabIndex = 43;
            this.button4G.Text = "4G";
            this.button4G.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.button4G.Click += new System.EventHandler(this.Button4G_Click);
            // 
            // button3G
            // 
            this.button3G.Highlight = true;
            this.button3G.Location = new System.Drawing.Point(102, 36);
            this.button3G.Name = "button3G";
            this.button3G.Size = new System.Drawing.Size(51, 27);
            this.button3G.Style = MetroFramework.MetroColorStyle.Lime;
            this.button3G.TabIndex = 42;
            this.button3G.Text = "3G";
            this.button3G.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.button3G.Click += new System.EventHandler(this.Button3G_Click);
            // 
            // button2G
            // 
            this.button2G.Highlight = true;
            this.button2G.Location = new System.Drawing.Point(30, 36);
            this.button2G.Name = "button2G";
            this.button2G.Size = new System.Drawing.Size(51, 27);
            this.button2G.Style = MetroFramework.MetroColorStyle.Lime;
            this.button2G.TabIndex = 41;
            this.button2G.Text = "2G";
            this.button2G.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.button2G.Click += new System.EventHandler(this.Button2G_Click);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.checkBoxOLED_Password);
            this.groupBox12.Controls.Add(this.label51);
            this.groupBox12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox12.Location = new System.Drawing.Point(414, 29);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(319, 106);
            this.groupBox12.TabIndex = 49;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Extra Setting";
            // 
            // checkBoxOLED_Password
            // 
            this.checkBoxOLED_Password.AutoSize = true;
            this.checkBoxOLED_Password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxOLED_Password.CustomBackground = true;
            this.checkBoxOLED_Password.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxOLED_Password.Location = new System.Drawing.Point(53, 59);
            this.checkBoxOLED_Password.Name = "checkBoxOLED_Password";
            this.checkBoxOLED_Password.Size = new System.Drawing.Size(191, 15);
            this.checkBoxOLED_Password.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxOLED_Password.TabIndex = 54;
            this.checkBoxOLED_Password.Text = "Show password on OLED screen";
            this.checkBoxOLED_Password.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxOLED_Password.UseStyleColors = true;
            this.checkBoxOLED_Password.UseVisualStyleBackColor = false;
            this.checkBoxOLED_Password.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CheckBoxOLED_Password_MouseClick_1);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label51.Location = new System.Drawing.Point(50, 40);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(219, 15);
            this.label51.TabIndex = 45;
            this.label51.Text = "Specifically for modem with OLED screen";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.buttonGetCurrentStat);
            this.groupBox5.Controls.Add(this.textBoxLTE_Band);
            this.groupBox5.Controls.Add(this.textBoxNetworkband);
            this.groupBox5.Controls.Add(this.textBoxNetworkMode);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Controls.Add(this.label43);
            this.groupBox5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox5.Location = new System.Drawing.Point(414, 152);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(319, 207);
            this.groupBox5.TabIndex = 48;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Network Band Status";
            // 
            // buttonGetCurrentStat
            // 
            this.buttonGetCurrentStat.Highlight = true;
            this.buttonGetCurrentStat.Location = new System.Drawing.Point(93, 152);
            this.buttonGetCurrentStat.Name = "buttonGetCurrentStat";
            this.buttonGetCurrentStat.Size = new System.Drawing.Size(112, 27);
            this.buttonGetCurrentStat.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonGetCurrentStat.TabIndex = 48;
            this.buttonGetCurrentStat.Text = "Get Current Status";
            this.buttonGetCurrentStat.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonGetCurrentStat.Click += new System.EventHandler(this.ButtonGetCurrentStat_Click);
            // 
            // textBoxLTE_Band
            // 
            this.textBoxLTE_Band.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxLTE_Band.CustomBackground = true;
            this.textBoxLTE_Band.Location = new System.Drawing.Point(164, 107);
            this.textBoxLTE_Band.Name = "textBoxLTE_Band";
            this.textBoxLTE_Band.Size = new System.Drawing.Size(105, 23);
            this.textBoxLTE_Band.TabIndex = 38;
            this.textBoxLTE_Band.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxNetworkband
            // 
            this.textBoxNetworkband.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxNetworkband.CustomBackground = true;
            this.textBoxNetworkband.Location = new System.Drawing.Point(164, 75);
            this.textBoxNetworkband.Name = "textBoxNetworkband";
            this.textBoxNetworkband.Size = new System.Drawing.Size(105, 23);
            this.textBoxNetworkband.TabIndex = 37;
            this.textBoxNetworkband.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxNetworkMode
            // 
            this.textBoxNetworkMode.BackColor = System.Drawing.Color.DarkGray;
            this.textBoxNetworkMode.CustomBackground = true;
            this.textBoxNetworkMode.Location = new System.Drawing.Point(164, 41);
            this.textBoxNetworkMode.Name = "textBoxNetworkMode";
            this.textBoxNetworkMode.Size = new System.Drawing.Size(105, 23);
            this.textBoxNetworkMode.TabIndex = 36;
            this.textBoxNetworkMode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(49, 110);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(57, 15);
            this.label45.TabIndex = 32;
            this.label45.Text = "LTE Band:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(49, 78);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(85, 15);
            this.label44.TabIndex = 31;
            this.label44.Text = "Network band:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(49, 44);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(89, 15);
            this.label43.TabIndex = 17;
            this.label43.Text = "Network Mode:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.checkBoxB3);
            this.groupBox6.Controls.Add(this.checkBoxB7);
            this.groupBox6.Controls.Add(this.checkBoxB8);
            this.groupBox6.Controls.Add(this.checkBoxB40);
            this.groupBox6.Controls.Add(this.checkBoxB38);
            this.groupBox6.Controls.Add(this.checkBoxB20);
            this.groupBox6.Controls.Add(this.checkBoxB1);
            this.groupBox6.Controls.Add(this.buttonApplyBand);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox6.Location = new System.Drawing.Point(37, 29);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(325, 210);
            this.groupBox6.TabIndex = 47;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "LTE Band configuration";
            // 
            // checkBoxB3
            // 
            this.checkBoxB3.AutoSize = true;
            this.checkBoxB3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxB3.CustomBackground = true;
            this.checkBoxB3.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxB3.Location = new System.Drawing.Point(26, 61);
            this.checkBoxB3.Name = "checkBoxB3";
            this.checkBoxB3.Size = new System.Drawing.Size(121, 15);
            this.checkBoxB3.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxB3.TabIndex = 54;
            this.checkBoxB3.Text = "B3 (FDD 1800MHz)";
            this.checkBoxB3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxB3.UseStyleColors = true;
            this.checkBoxB3.UseVisualStyleBackColor = false;
            this.checkBoxB3.CheckStateChanged += new System.EventHandler(this.CheckBoxB3_CheckStateChanged);
            // 
            // checkBoxB7
            // 
            this.checkBoxB7.AutoSize = true;
            this.checkBoxB7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxB7.CustomBackground = true;
            this.checkBoxB7.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxB7.Location = new System.Drawing.Point(26, 89);
            this.checkBoxB7.Name = "checkBoxB7";
            this.checkBoxB7.Size = new System.Drawing.Size(121, 15);
            this.checkBoxB7.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxB7.TabIndex = 53;
            this.checkBoxB7.Text = "B7 (FDD 2600MHz)";
            this.checkBoxB7.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxB7.UseStyleColors = true;
            this.checkBoxB7.UseVisualStyleBackColor = false;
            this.checkBoxB7.CheckStateChanged += new System.EventHandler(this.CheckBoxB7_CheckStateChanged);
            // 
            // checkBoxB8
            // 
            this.checkBoxB8.AutoSize = true;
            this.checkBoxB8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxB8.CustomBackground = true;
            this.checkBoxB8.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxB8.Location = new System.Drawing.Point(26, 117);
            this.checkBoxB8.Name = "checkBoxB8";
            this.checkBoxB8.Size = new System.Drawing.Size(115, 15);
            this.checkBoxB8.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxB8.TabIndex = 52;
            this.checkBoxB8.Text = "B8 (FDD 900MHz)";
            this.checkBoxB8.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxB8.UseStyleColors = true;
            this.checkBoxB8.UseVisualStyleBackColor = false;
            this.checkBoxB8.CheckStateChanged += new System.EventHandler(this.CheckBoxB8_CheckStateChanged);
            // 
            // checkBoxB40
            // 
            this.checkBoxB40.AutoSize = true;
            this.checkBoxB40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxB40.CustomBackground = true;
            this.checkBoxB40.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxB40.Location = new System.Drawing.Point(171, 91);
            this.checkBoxB40.Name = "checkBoxB40";
            this.checkBoxB40.Size = new System.Drawing.Size(127, 15);
            this.checkBoxB40.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxB40.TabIndex = 51;
            this.checkBoxB40.Text = "B40 (TDD 2300MHz)";
            this.checkBoxB40.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxB40.UseStyleColors = true;
            this.checkBoxB40.UseVisualStyleBackColor = false;
            this.checkBoxB40.CheckStateChanged += new System.EventHandler(this.CheckBoxB40_CheckStateChanged);
            // 
            // checkBoxB38
            // 
            this.checkBoxB38.AutoSize = true;
            this.checkBoxB38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxB38.CustomBackground = true;
            this.checkBoxB38.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxB38.Location = new System.Drawing.Point(171, 62);
            this.checkBoxB38.Name = "checkBoxB38";
            this.checkBoxB38.Size = new System.Drawing.Size(127, 15);
            this.checkBoxB38.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxB38.TabIndex = 50;
            this.checkBoxB38.Text = "B38 (TDD 2600MHz)";
            this.checkBoxB38.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxB38.UseStyleColors = true;
            this.checkBoxB38.UseVisualStyleBackColor = false;
            this.checkBoxB38.CheckStateChanged += new System.EventHandler(this.CheckBoxB38_CheckStateChanged);
            // 
            // checkBoxB20
            // 
            this.checkBoxB20.AutoSize = true;
            this.checkBoxB20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxB20.CustomBackground = true;
            this.checkBoxB20.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxB20.Location = new System.Drawing.Point(171, 33);
            this.checkBoxB20.Name = "checkBoxB20";
            this.checkBoxB20.Size = new System.Drawing.Size(121, 15);
            this.checkBoxB20.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxB20.TabIndex = 49;
            this.checkBoxB20.Text = "B20 (FDD 800MHz)";
            this.checkBoxB20.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxB20.UseStyleColors = true;
            this.checkBoxB20.UseVisualStyleBackColor = false;
            this.checkBoxB20.CheckStateChanged += new System.EventHandler(this.CheckBoxB20_CheckStateChanged);
            // 
            // checkBoxB1
            // 
            this.checkBoxB1.AutoSize = true;
            this.checkBoxB1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.checkBoxB1.CustomBackground = true;
            this.checkBoxB1.ForeColor = System.Drawing.Color.Transparent;
            this.checkBoxB1.Location = new System.Drawing.Point(26, 33);
            this.checkBoxB1.Name = "checkBoxB1";
            this.checkBoxB1.Size = new System.Drawing.Size(121, 15);
            this.checkBoxB1.Style = MetroFramework.MetroColorStyle.Lime;
            this.checkBoxB1.TabIndex = 48;
            this.checkBoxB1.Text = "B1 (FDD 2100MHz)";
            this.checkBoxB1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.checkBoxB1.UseStyleColors = true;
            this.checkBoxB1.UseVisualStyleBackColor = false;
            this.checkBoxB1.CheckStateChanged += new System.EventHandler(this.CheckBoxB1_CheckStateChanged);
            // 
            // buttonApplyBand
            // 
            this.buttonApplyBand.Highlight = true;
            this.buttonApplyBand.Location = new System.Drawing.Point(115, 170);
            this.buttonApplyBand.Name = "buttonApplyBand";
            this.buttonApplyBand.Size = new System.Drawing.Size(71, 27);
            this.buttonApplyBand.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonApplyBand.TabIndex = 47;
            this.buttonApplyBand.Text = "Apply";
            this.buttonApplyBand.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonApplyBand.Click += new System.EventHandler(this.ButtonApplyBand_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label32.Location = new System.Drawing.Point(81, 145);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(163, 15);
            this.label32.TabIndex = 46;
            this.label32.Text = "You can lock up to 3 LTE band";
            // 
            // metroTabPage5
            // 
            this.metroTabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroTabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroTabPage5.Controls.Add(this.comboBoxAPIList);
            this.metroTabPage5.Controls.Add(this.buttonpostAPI);
            this.metroTabPage5.Controls.Add(this.buttonApplyAPI);
            this.metroTabPage5.Controls.Add(this.comboBoxAPIs);
            this.metroTabPage5.Controls.Add(this.label29);
            this.metroTabPage5.Controls.Add(this.richTextBox2);
            this.metroTabPage5.Controls.Add(this.label37);
            this.metroTabPage5.Controls.Add(this.richTextBox1);
            this.metroTabPage5.CustomBackground = true;
            this.metroTabPage5.HorizontalScrollbarBarColor = true;
            this.metroTabPage5.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage5.Name = "metroTabPage5";
            this.metroTabPage5.Size = new System.Drawing.Size(773, 390);
            this.metroTabPage5.TabIndex = 4;
            this.metroTabPage5.Text = "API Control";
            this.metroTabPage5.VerticalScrollbarBarColor = true;
            // 
            // comboBoxAPIList
            // 
            this.comboBoxAPIList.FormattingEnabled = true;
            this.comboBoxAPIList.ItemHeight = 23;
            this.comboBoxAPIList.Location = new System.Drawing.Point(22, 352);
            this.comboBoxAPIList.Name = "comboBoxAPIList";
            this.comboBoxAPIList.Size = new System.Drawing.Size(296, 29);
            this.comboBoxAPIList.Sorted = true;
            this.comboBoxAPIList.Style = MetroFramework.MetroColorStyle.Lime;
            this.comboBoxAPIList.TabIndex = 43;
            this.comboBoxAPIList.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.comboBoxAPIList.SelectedIndexChanged += new System.EventHandler(this.ComboBoxAPIList_SelectedIndexChanged_2);
            // 
            // buttonpostAPI
            // 
            this.buttonpostAPI.Highlight = true;
            this.buttonpostAPI.Location = new System.Drawing.Point(701, 352);
            this.buttonpostAPI.Name = "buttonpostAPI";
            this.buttonpostAPI.Size = new System.Drawing.Size(50, 29);
            this.buttonpostAPI.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonpostAPI.TabIndex = 42;
            this.buttonpostAPI.Text = "POST";
            this.buttonpostAPI.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonpostAPI.Click += new System.EventHandler(this.ButtonpostAPI_Click);
            // 
            // buttonApplyAPI
            // 
            this.buttonApplyAPI.Highlight = true;
            this.buttonApplyAPI.Location = new System.Drawing.Point(324, 351);
            this.buttonApplyAPI.Name = "buttonApplyAPI";
            this.buttonApplyAPI.Size = new System.Drawing.Size(50, 29);
            this.buttonApplyAPI.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonApplyAPI.TabIndex = 41;
            this.buttonApplyAPI.Text = "GET";
            this.buttonApplyAPI.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonApplyAPI.Click += new System.EventHandler(this.ButtonApplyAPI_Click_1);
            // 
            // comboBoxAPIs
            // 
            this.comboBoxAPIs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxAPIs.FormattingEnabled = true;
            this.comboBoxAPIs.Location = new System.Drawing.Point(22, 358);
            this.comboBoxAPIs.Name = "comboBoxAPIs";
            this.comboBoxAPIs.Size = new System.Drawing.Size(257, 21);
            this.comboBoxAPIs.Sorted = true;
            this.comboBoxAPIs.TabIndex = 26;
            this.comboBoxAPIs.Visible = false;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label29.Location = new System.Drawing.Point(396, 7);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(73, 15);
            this.label29.TabIndex = 24;
            this.label29.Text = "Write to API:";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.DarkGray;
            this.richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox2.Font = new System.Drawing.Font("Segoe UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.Location = new System.Drawing.Point(399, 23);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.richTextBox2.Size = new System.Drawing.Size(352, 323);
            this.richTextBox2.TabIndex = 22;
            this.richTextBox2.Text = "";
            this.richTextBox2.WordWrap = false;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label37.Location = new System.Drawing.Point(19, 7);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(60, 15);
            this.label37.TabIndex = 21;
            this.label37.Text = "Response:";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.DarkGray;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox1.Font = new System.Drawing.Font("Segoe UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(22, 23);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.richTextBox1.Size = new System.Drawing.Size(352, 323);
            this.richTextBox1.TabIndex = 19;
            this.richTextBox1.Text = "";
            this.richTextBox1.WordWrap = false;
            // 
            // metroTabPage9
            // 
            this.metroTabPage9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroTabPage9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroTabPage9.Controls.Add(this.groupBox15);
            this.metroTabPage9.Controls.Add(this.groupBox14);
            this.metroTabPage9.CustomBackground = true;
            this.metroTabPage9.HorizontalScrollbarBarColor = true;
            this.metroTabPage9.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage9.Name = "metroTabPage9";
            this.metroTabPage9.Size = new System.Drawing.Size(773, 390);
            this.metroTabPage9.TabIndex = 8;
            this.metroTabPage9.Text = "SMS";
            this.metroTabPage9.VerticalScrollbarBarColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label56);
            this.groupBox15.Controls.Add(this.label41);
            this.groupBox15.Controls.Add(this.btnSMSSend);
            this.groupBox15.Controls.Add(this.label42);
            this.groupBox15.Controls.Add(this.rtbSMSContent);
            this.groupBox15.Controls.Add(this.rtbSMSRecipient);
            this.groupBox15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox15.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox15.Location = new System.Drawing.Point(9, 8);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(753, 154);
            this.groupBox15.TabIndex = 80;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Send SMS";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label56.Location = new System.Drawing.Point(676, 62);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(29, 17);
            this.label56.TabIndex = 78;
            this.label56.Text = "160";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label41.Location = new System.Drawing.Point(61, 16);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(70, 17);
            this.label41.TabIndex = 57;
            this.label41.Text = "Recipients:";
            // 
            // btnSMSSend
            // 
            this.btnSMSSend.Highlight = true;
            this.btnSMSSend.Location = new System.Drawing.Point(209, 36);
            this.btnSMSSend.Name = "btnSMSSend";
            this.btnSMSSend.Size = new System.Drawing.Size(96, 23);
            this.btnSMSSend.Style = MetroFramework.MetroColorStyle.Lime;
            this.btnSMSSend.TabIndex = 45;
            this.btnSMSSend.Text = "Send SMS";
            this.btnSMSSend.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnSMSSend.Click += new System.EventHandler(this.btnSMSSend_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label42.Location = new System.Drawing.Point(61, 62);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(56, 17);
            this.label42.TabIndex = 58;
            this.label42.Text = "Content:";
            // 
            // rtbSMSContent
            // 
            this.rtbSMSContent.BackColor = System.Drawing.Color.DarkGray;
            this.rtbSMSContent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtbSMSContent.Location = new System.Drawing.Point(64, 82);
            this.rtbSMSContent.MaxLength = 160;
            this.rtbSMSContent.Name = "rtbSMSContent";
            this.rtbSMSContent.Size = new System.Drawing.Size(641, 58);
            this.rtbSMSContent.TabIndex = 55;
            this.rtbSMSContent.Text = "Send from Huawei Router Tool";
            this.rtbSMSContent.TextChanged += new System.EventHandler(this.rtbSMSContent_TextChanged);
            // 
            // rtbSMSRecipient
            // 
            this.rtbSMSRecipient.BackColor = System.Drawing.Color.DarkGray;
            this.rtbSMSRecipient.CustomBackground = true;
            this.rtbSMSRecipient.Location = new System.Drawing.Point(64, 36);
            this.rtbSMSRecipient.Name = "rtbSMSRecipient";
            this.rtbSMSRecipient.Size = new System.Drawing.Size(139, 23);
            this.rtbSMSRecipient.TabIndex = 61;
            this.rtbSMSRecipient.Text = "0176612934";
            this.rtbSMSRecipient.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.dataGridView1);
            this.groupBox14.Controls.Add(this.metroButton1);
            this.groupBox14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox14.Location = new System.Drawing.Point(9, 165);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(753, 216);
            this.groupBox14.TabIndex = 79;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "SMS List";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowDrop = true;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(85)))), ((int)(((byte)(88)))));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCellsExceptHeader;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(69)))), ((int)(((byte)(71)))));
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.DarkGray;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.DarkGray;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dataGridView1.Location = new System.Drawing.Point(56, 51);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Silver;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(641, 153);
            this.dataGridView1.TabIndex = 77;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // metroButton1
            // 
            this.metroButton1.Highlight = true;
            this.metroButton1.Location = new System.Drawing.Point(56, 22);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(96, 23);
            this.metroButton1.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroButton1.TabIndex = 63;
            this.metroButton1.Text = "Retrieve SMS";
            this.metroButton1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click_3);
            // 
            // metroTabPage8
            // 
            this.metroTabPage8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroTabPage8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroTabPage8.Controls.Add(this.label59);
            this.metroTabPage8.Controls.Add(this.label58);
            this.metroTabPage8.Controls.Add(this.tbUSSDCMD);
            this.metroTabPage8.Controls.Add(this.richTextBox3);
            this.metroTabPage8.Controls.Add(this.metroButton2);
            this.metroTabPage8.Controls.Add(this.listBox1);
            this.metroTabPage8.Controls.Add(this.menuStrip2);
            this.metroTabPage8.CustomBackground = true;
            this.metroTabPage8.HorizontalScrollbarBarColor = true;
            this.metroTabPage8.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage8.Name = "metroTabPage8";
            this.metroTabPage8.Size = new System.Drawing.Size(773, 390);
            this.metroTabPage8.TabIndex = 9;
            this.metroTabPage8.Text = "USSD";
            this.metroTabPage8.VerticalScrollbarBarColor = true;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label59.Location = new System.Drawing.Point(211, 124);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(70, 15);
            this.label59.TabIndex = 50;
            this.label59.Text = "USSD result:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label58.Location = new System.Drawing.Point(211, 71);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(159, 15);
            this.label58.TabIndex = 45;
            this.label58.Text = "USSD command (e.g *100#) :";
            // 
            // tbUSSDCMD
            // 
            this.tbUSSDCMD.BackColor = System.Drawing.Color.DarkGray;
            this.tbUSSDCMD.CustomBackground = true;
            this.tbUSSDCMD.Location = new System.Drawing.Point(214, 89);
            this.tbUSSDCMD.Name = "tbUSSDCMD";
            this.tbUSSDCMD.Size = new System.Drawing.Size(93, 23);
            this.tbUSSDCMD.TabIndex = 48;
            this.tbUSSDCMD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // richTextBox3
            // 
            this.richTextBox3.BackColor = System.Drawing.Color.DarkGray;
            this.richTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox3.Location = new System.Drawing.Point(214, 142);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.ReadOnly = true;
            this.richTextBox3.Size = new System.Drawing.Size(346, 176);
            this.richTextBox3.TabIndex = 46;
            this.richTextBox3.Text = "";
            // 
            // metroButton2
            // 
            this.metroButton2.Highlight = true;
            this.metroButton2.Location = new System.Drawing.Point(313, 89);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(109, 23);
            this.metroButton2.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroButton2.TabIndex = 42;
            this.metroButton2.Text = "Send command";
            this.metroButton2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(321, 181);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(141, 69);
            this.listBox1.TabIndex = 49;
            this.listBox1.Visible = false;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // menuStrip2
            // 
            this.menuStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem4});
            this.menuStrip2.Location = new System.Drawing.Point(379, 29);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(89, 24);
            this.menuStrip2.TabIndex = 4;
            this.menuStrip2.Text = "menuStrip2";
            this.menuStrip2.Visible = false;
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Enabled = false;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem2.Text = "Save Device Info";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem3.Text = "Exit";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(44, 20);
            this.toolStripMenuItem4.Text = "Help";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(107, 22);
            this.toolStripMenuItem5.Text = "About";
            // 
            // metroTabPage6
            // 
            this.metroTabPage6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroTabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroTabPage6.Controls.Add(this.richTextBoxLog);
            this.metroTabPage6.Controls.Add(this.label33);
            this.metroTabPage6.Controls.Add(this.button19);
            this.metroTabPage6.Controls.Add(this.button20);
            this.metroTabPage6.Controls.Add(this.groupBox8);
            this.metroTabPage6.Controls.Add(this.groupBox3);
            this.metroTabPage6.Controls.Add(this.groupBox2);
            this.metroTabPage6.Controls.Add(this.groupBox4);
            this.metroTabPage6.Controls.Add(this.menuStrip1);
            this.metroTabPage6.CustomBackground = true;
            this.metroTabPage6.HorizontalScrollbarBarColor = true;
            this.metroTabPage6.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage6.Name = "metroTabPage6";
            this.metroTabPage6.Size = new System.Drawing.Size(773, 390);
            this.metroTabPage6.TabIndex = 5;
            this.metroTabPage6.Text = "Log";
            this.metroTabPage6.VerticalScrollbarBarColor = true;
            // 
            // richTextBoxLog
            // 
            this.richTextBoxLog.BackColor = System.Drawing.Color.DarkGray;
            this.richTextBoxLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBoxLog.Location = new System.Drawing.Point(23, 56);
            this.richTextBoxLog.Name = "richTextBoxLog";
            this.richTextBoxLog.Size = new System.Drawing.Size(727, 295);
            this.richTextBoxLog.TabIndex = 45;
            this.richTextBoxLog.Text = "";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.label33.Location = new System.Drawing.Point(20, 40);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(30, 15);
            this.label33.TabIndex = 46;
            this.label33.Text = "Log:";
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(162, 236);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(180, 36);
            this.button19.TabIndex = 47;
            this.button19.Text = "Open Special Application Setting";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Visible = false;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(362, 260);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(151, 36);
            this.button20.TabIndex = 48;
            this.button20.Text = "Open Virtual Server Setting";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Visible = false;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.buttonDeleteProfile);
            this.groupBox8.Controls.Add(this.buttonAddProfile);
            this.groupBox8.Controls.Add(this.buttonViewProfileList);
            this.groupBox8.Location = new System.Drawing.Point(79, 68);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(200, 145);
            this.groupBox8.TabIndex = 49;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Profile Management";
            // 
            // buttonDeleteProfile
            // 
            this.buttonDeleteProfile.Location = new System.Drawing.Point(46, 98);
            this.buttonDeleteProfile.Name = "buttonDeleteProfile";
            this.buttonDeleteProfile.Size = new System.Drawing.Size(108, 23);
            this.buttonDeleteProfile.TabIndex = 4;
            this.buttonDeleteProfile.Text = "Delete Profile";
            this.buttonDeleteProfile.UseVisualStyleBackColor = true;
            // 
            // buttonAddProfile
            // 
            this.buttonAddProfile.Location = new System.Drawing.Point(46, 61);
            this.buttonAddProfile.Name = "buttonAddProfile";
            this.buttonAddProfile.Size = new System.Drawing.Size(108, 23);
            this.buttonAddProfile.TabIndex = 3;
            this.buttonAddProfile.Text = "Add New Profile";
            this.buttonAddProfile.UseVisualStyleBackColor = true;
            // 
            // buttonViewProfileList
            // 
            this.buttonViewProfileList.Location = new System.Drawing.Point(46, 24);
            this.buttonViewProfileList.Name = "buttonViewProfileList";
            this.buttonViewProfileList.Size = new System.Drawing.Size(108, 23);
            this.buttonViewProfileList.TabIndex = 1;
            this.buttonViewProfileList.Text = "View Profile List";
            this.buttonViewProfileList.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label50);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Controls.Add(this.label48);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Location = new System.Drawing.Point(212, 118);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(425, 152);
            this.groupBox3.TabIndex = 51;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Speed test";
            this.groupBox3.Visible = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(227, 82);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(83, 13);
            this.label50.TabIndex = 30;
            this.label50.Text = "Upload Speed:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(19, 82);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(99, 13);
            this.label49.TabIndex = 29;
            this.label49.Text = "Download Speed:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(19, 29);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(148, 13);
            this.label48.TabIndex = 28;
            this.label48.Text = "Selected Server (By Latency):";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(22, 45);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(380, 22);
            this.textBox4.TabIndex = 22;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(126, 79);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(72, 22);
            this.textBox5.TabIndex = 26;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(325, 79);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(76, 22);
            this.textBox6.TabIndex = 27;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(22, 111);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(73, 24);
            this.button4.TabIndex = 21;
            this.button4.Text = "Start";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Location = new System.Drawing.Point(29, 118);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(163, 152);
            this.groupBox2.TabIndex = 50;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ping test";
            this.groupBox2.Visible = false;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(31, 111);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(42, 13);
            this.label47.TabIndex = 29;
            this.label47.Text = "Result:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(31, 33);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(67, 13);
            this.label46.TabIndex = 28;
            this.label46.Text = "Select Host:";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1.1.1.1",
            "8.8.8.8",
            "1.0.0.1",
            "8.8.4.4"});
            this.comboBox2.Location = new System.Drawing.Point(34, 49);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(98, 21);
            this.comboBox2.TabIndex = 11;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(34, 78);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(98, 23);
            this.button3.TabIndex = 12;
            this.button3.Text = "Ping";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(83, 108);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(49, 22);
            this.textBox7.TabIndex = 27;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBoxWLANSec);
            this.groupBox4.Controls.Add(this.checkBoxEnableSSID);
            this.groupBox4.Controls.Add(this.buttonApplyWLAN);
            this.groupBox4.Controls.Add(this.textBoxPre_shared);
            this.groupBox4.Controls.Add(this.textBoxSSID);
            this.groupBox4.Controls.Add(this.label54);
            this.groupBox4.Controls.Add(this.label53);
            this.groupBox4.Controls.Add(this.label52);
            this.groupBox4.Location = new System.Drawing.Point(193, 126);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(280, 163);
            this.groupBox4.TabIndex = 52;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "WLAN Basic Setting";
            this.groupBox4.Visible = false;
            // 
            // comboBoxWLANSec
            // 
            this.comboBoxWLANSec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxWLANSec.FormattingEnabled = true;
            this.comboBoxWLANSec.Items.AddRange(new object[] {
            "OPEN",
            "WPA2-PSK",
            "WPA/WPA2-PSK"});
            this.comboBoxWLANSec.Location = new System.Drawing.Point(147, 51);
            this.comboBoxWLANSec.Name = "comboBoxWLANSec";
            this.comboBoxWLANSec.Size = new System.Drawing.Size(111, 21);
            this.comboBoxWLANSec.TabIndex = 52;
            // 
            // checkBoxEnableSSID
            // 
            this.checkBoxEnableSSID.AutoSize = true;
            this.checkBoxEnableSSID.Location = new System.Drawing.Point(26, 100);
            this.checkBoxEnableSSID.Name = "checkBoxEnableSSID";
            this.checkBoxEnableSSID.Size = new System.Drawing.Size(76, 17);
            this.checkBoxEnableSSID.TabIndex = 49;
            this.checkBoxEnableSSID.Text = "Hide SSID";
            this.checkBoxEnableSSID.UseVisualStyleBackColor = true;
            // 
            // textBoxPre_shared
            // 
            this.textBoxPre_shared.Location = new System.Drawing.Point(147, 75);
            this.textBoxPre_shared.Name = "textBoxPre_shared";
            this.textBoxPre_shared.Size = new System.Drawing.Size(111, 22);
            this.textBoxPre_shared.TabIndex = 48;
            // 
            // textBoxSSID
            // 
            this.textBoxSSID.Location = new System.Drawing.Point(147, 27);
            this.textBoxSSID.Name = "textBoxSSID";
            this.textBoxSSID.Size = new System.Drawing.Size(111, 22);
            this.textBoxSSID.TabIndex = 46;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(23, 78);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(112, 13);
            this.label54.TabIndex = 45;
            this.label54.Text = "WPA pre-shared key:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(23, 54);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(82, 13);
            this.label53.TabIndex = 44;
            this.label53.Text = "Security mode:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(23, 30);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(33, 13);
            this.label52.TabIndex = 43;
            this.label52.Text = "SSID:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(379, 29);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(89, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveDeviceInfoToolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveDeviceInfoToolStripMenuItem1
            // 
            this.saveDeviceInfoToolStripMenuItem1.Enabled = false;
            this.saveDeviceInfoToolStripMenuItem1.Name = "saveDeviceInfoToolStripMenuItem1";
            this.saveDeviceInfoToolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.saveDeviceInfoToolStripMenuItem1.Text = "Save Device Info";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // metroTabPage7
            // 
            this.metroTabPage7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroTabPage7.Controls.Add(this.pictureBox1);
            this.metroTabPage7.Controls.Add(this.AboutLog);
            this.metroTabPage7.Controls.Add(this.linkLabel1);
            this.metroTabPage7.Controls.Add(this.metroLabel4);
            this.metroTabPage7.Controls.Add(this.metroLabel2);
            this.metroTabPage7.Controls.Add(this.pictureBox2);
            this.metroTabPage7.Controls.Add(this.metroLabel1);
            this.metroTabPage7.CustomBackground = true;
            this.metroTabPage7.HorizontalScrollbarBarColor = true;
            this.metroTabPage7.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage7.Name = "metroTabPage7";
            this.metroTabPage7.Size = new System.Drawing.Size(773, 390);
            this.metroTabPage7.TabIndex = 6;
            this.metroTabPage7.Text = "About";
            this.metroTabPage7.VerticalScrollbarBarColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(434, 79);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 25);
            this.pictureBox1.TabIndex = 55;
            this.pictureBox1.TabStop = false;
            // 
            // AboutLog
            // 
            this.AboutLog.BackColor = System.Drawing.Color.DarkGray;
            this.AboutLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AboutLog.Location = new System.Drawing.Point(20, 153);
            this.AboutLog.Name = "AboutLog";
            this.AboutLog.ReadOnly = true;
            this.AboutLog.Size = new System.Drawing.Size(733, 222);
            this.AboutLog.TabIndex = 54;
            this.AboutLog.Text = resources.GetString("AboutLog.Text");
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.SystemColors.Highlight;
            this.linkLabel1.Location = new System.Drawing.Point(310, 83);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(118, 17);
            this.linkLabel1.TabIndex = 7;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "© pearlxcore 2020";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel1_LinkClicked);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroLabel4.CustomBackground = true;
            this.metroLabel4.CustomForeColor = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.metroLabel4.Location = new System.Drawing.Point(170, 48);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(433, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel4.TabIndex = 6;
            this.metroLabel4.Text = "Thanks for making this possible : HSPDev | Raggles | valexi | zainuddin";
            this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroLabel2.CustomBackground = true;
            this.metroLabel2.CustomForeColor = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.metroLabel2.Location = new System.Drawing.Point(280, 115);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(131, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel2.TabIndex = 4;
            this.metroLabel2.Text = "If you like my work..";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(417, 115);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(76, 19);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.PictureBox2_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.metroLabel1.CustomBackground = true;
            this.metroLabel1.CustomForeColor = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.metroLabel1.Location = new System.Drawing.Point(93, 16);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(587, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "\'Huawei Router Tool\' is a program to interact with Huawei routers with graphical " +
    "user interface.";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Location = new System.Drawing.Point(21, 57);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(777, 1);
            this.panel2.TabIndex = 43;
            // 
            // buttonWebpage
            // 
            this.buttonWebpage.Highlight = true;
            this.buttonWebpage.Location = new System.Drawing.Point(689, 76);
            this.buttonWebpage.Name = "buttonWebpage";
            this.buttonWebpage.Size = new System.Drawing.Size(109, 48);
            this.buttonWebpage.Style = MetroFramework.MetroColorStyle.Lime;
            this.buttonWebpage.TabIndex = 41;
            this.buttonWebpage.Text = "Router Homepage";
            this.buttonWebpage.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.buttonWebpage.Click += new System.EventHandler(this.MetroButton1_Click_2);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Location = new System.Drawing.Point(21, 149);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(777, 1);
            this.panel1.TabIndex = 44;
            // 
            // backgroundWorkerDetect_eerorCODE
            // 
            this.backgroundWorkerDetect_eerorCODE.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorkerDetect_eerorCODE_DoWork);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyPhoneNumberToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(187, 26);
            // 
            // copyPhoneNumberToolStripMenuItem
            // 
            this.copyPhoneNumberToolStripMenuItem.Name = "copyPhoneNumberToolStripMenuItem";
            this.copyPhoneNumberToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.copyPhoneNumberToolStripMenuItem.Text = "Copy Phone Number";
            this.copyPhoneNumberToolStripMenuItem.Click += new System.EventHandler(this.copyPhoneNumberToolStripMenuItem_Click);
            // 
            // btnRefreshMAC
            // 
            this.btnRefreshMAC.Highlight = true;
            this.btnRefreshMAC.Location = new System.Drawing.Point(149, 96);
            this.btnRefreshMAC.Name = "btnRefreshMAC";
            this.btnRefreshMAC.Size = new System.Drawing.Size(100, 23);
            this.btnRefreshMAC.Style = MetroFramework.MetroColorStyle.Lime;
            this.btnRefreshMAC.TabIndex = 91;
            this.btnRefreshMAC.Text = "Refresh";
            this.btnRefreshMAC.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.btnRefreshMAC.Click += new System.EventHandler(this.btnRefreshMAC_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(818, 602);
            this.Controls.Add(this.buttonWebpage);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.buttonShutdown);
            this.Controls.Add(this.buttonReboot);
            this.Controls.Add(this.buttonLogin);
            this.Controls.Add(this.checkBoxRememberUserpass);
            this.Controls.Add(this.textBoxPassword);
            this.Controls.Add(this.textBoxUsername);
            this.Controls.Add(this.textBoxIP);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.metroTabControl1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Resizable = false;
            this.ShadowType = MetroFramework.Forms.MetroForm.MetroFormShadowType.DropShadow;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Style = MetroFramework.MetroColorStyle.Lime;
            this.Text = "Huawei Router Tool";
            this.TextAlign = System.Windows.Forms.VisualStyles.HorizontalAlign.Center;
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.metroTabPage2.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.metroTabPage4.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.metroTabPage5.ResumeLayout(false);
            this.metroTabPage5.PerformLayout();
            this.metroTabPage9.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.metroTabPage8.ResumeLayout(false);
            this.metroTabPage8.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.metroTabPage6.ResumeLayout(false);
            this.metroTabPage6.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.metroTabPage7.ResumeLayout(false);
            this.metroTabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorkerDeviceInfo;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.ComponentModel.BackgroundWorker backgroundWorkerLetMeSeeUrs;
        private System.ComponentModel.BackgroundWorker backgroundWorkerApplyBand;
        private System.ComponentModel.BackgroundWorker backgroundWorkerPerformanceTool;
        private System.ComponentModel.BackgroundWorker backgroundWorkerAPI;
        private System.ComponentModel.BackgroundWorker backgroundWorkerLogin_Reboot_Shutdown;
        private System.ComponentModel.BackgroundWorker backgroundWorkerSpeedtest;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label30;
        private System.ComponentModel.BackgroundWorker backgroundWorkerCOnnectedDeviceAndMacFilter;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label57;
        private MetroFramework.Controls.MetroButton buttonShutdown;
        private MetroFramework.Controls.MetroButton buttonReboot;
        private MetroFramework.Controls.MetroButton buttonLogin;
        private MetroFramework.Controls.MetroCheckBox checkBoxRememberUserpass;
        private MetroFramework.Controls.MetroTextBox textBoxPassword;
        private MetroFramework.Controls.MetroTextBox textBoxUsername;
        private MetroFramework.Controls.MetroTextBox textBoxIP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTextBox textBoxCurrentDownloadRate;
        private MetroFramework.Controls.MetroTextBox textBoxCurrentUploadRate;
        private MetroFramework.Controls.MetroTextBox textBoxCurrentConnectTime;
        private MetroFramework.Controls.MetroTextBox textBoxTotalUpload;
        private MetroFramework.Controls.MetroTextBox textBoxTotalDownload;
        private MetroFramework.Controls.MetroTextBox textBoxMNC;
        private MetroFramework.Controls.MetroTextBox textBoxTotalConnectTime;
        private MetroFramework.Controls.MetroTextBox textBoxModel;
        private MetroFramework.Controls.MetroTextBox textBoxSerialNumber;
        private MetroFramework.Controls.MetroTextBox textBoxImei;
        private MetroFramework.Controls.MetroTextBox textBoxIccid;
        private MetroFramework.Controls.MetroTextBox textBoxMsisdn;
        private MetroFramework.Controls.MetroTextBox textBoxHardwareVersion;
        private MetroFramework.Controls.MetroTextBox textBoxSoftwareVersion;
        private MetroFramework.Controls.MetroTextBox textBoxMacAddress;
        private MetroFramework.Controls.MetroTextBox textBoxWorkmode;
        private MetroFramework.Controls.MetroTextBox textBoxNetworkProvider;
        private MetroFramework.Controls.MetroTextBox textBoxsimLock;
        private MetroFramework.Controls.MetroTextBox textBoxWebuiVersion;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ListView listView1;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.GroupBox groupBox7;
        private MetroFramework.Controls.MetroTabPage metroTabPage4;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label32;
        private MetroFramework.Controls.MetroTabPage metroTabPage5;
        private System.Windows.Forms.ComboBox comboBoxAPIs;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private MetroFramework.Controls.MetroTabPage metroTabPage6;
        public System.Windows.Forms.RichTextBox richTextBoxLog;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button buttonDeleteProfile;
        private System.Windows.Forms.Button buttonAddProfile;
        private System.Windows.Forms.Button buttonViewProfileList;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        public System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox comboBoxWLANSec;
        private System.Windows.Forms.CheckBox checkBoxEnableSSID;
        private System.Windows.Forms.Button buttonApplyWLAN;
        private System.Windows.Forms.TextBox textBoxPre_shared;
        private System.Windows.Forms.TextBox textBoxSSID;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveDeviceInfoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroTextBox textBoxRSSI;
        private MetroFramework.Controls.MetroTextBox textBoxSINR;
        private MetroFramework.Controls.MetroTextBox textBoxRSRQ;
        private MetroFramework.Controls.MetroTextBox textBoxRSRP;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private MetroFramework.Controls.MetroButton buttonRefreshConnectedClient;
        private MetroFramework.Controls.MetroButton buttonUnblockAll;
        private MetroFramework.Controls.MetroButton buttonBlockDevice;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC0;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC1;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC2;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC3;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC4;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC5;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC9;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC6;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC8;
        private MetroFramework.Controls.MetroTextBox textBoxBlockMAC7;
        private MetroFramework.Controls.MetroTextBox textBoxSIP;
        private MetroFramework.Controls.MetroTextBox textBoxDMZ;
        private MetroFramework.Controls.MetroCheckBox checkBoxDMZ;
        private MetroFramework.Controls.MetroCheckBox checkBoxNAT;
        private MetroFramework.Controls.MetroCheckBox checkBoxSIP;
        private MetroFramework.Controls.MetroCheckBox checkBoxUPnP;
        private MetroFramework.Controls.MetroCheckBox checkBoxMobileConnection;
        private MetroFramework.Controls.MetroButton buttonSaveDevicePW;
        private MetroFramework.Controls.MetroTextBox textBoxNewPW;
        private MetroFramework.Controls.MetroTextBox textBoxCurrentPW;
        private MetroFramework.Controls.MetroCheckBox checkBoxFW1;
        private MetroFramework.Controls.MetroCheckBox checkBoxFW2;
        private MetroFramework.Controls.MetroCheckBox checkBoxFW3;
        private MetroFramework.Controls.MetroComboBox comboBoxDeviceMode;
        private MetroFramework.Controls.MetroButton buttonRestore;
        private MetroFramework.Controls.MetroButton buttonAuto;
        private MetroFramework.Controls.MetroButton button4G;
        private MetroFramework.Controls.MetroButton button3G;
        private MetroFramework.Controls.MetroButton button2G;
        private MetroFramework.Controls.MetroButton buttonApplyBand;
        private MetroFramework.Controls.MetroCheckBox checkBoxB3;
        private MetroFramework.Controls.MetroCheckBox checkBoxB7;
        private MetroFramework.Controls.MetroCheckBox checkBoxB8;
        private MetroFramework.Controls.MetroCheckBox checkBoxB40;
        private MetroFramework.Controls.MetroCheckBox checkBoxB38;
        private MetroFramework.Controls.MetroCheckBox checkBoxB20;
        private MetroFramework.Controls.MetroCheckBox checkBoxB1;
        private MetroFramework.Controls.MetroCheckBox checkBoxOLED_Password;
        private MetroFramework.Controls.MetroButton buttonGetCurrentStat;
        private MetroFramework.Controls.MetroTextBox textBoxLTE_Band;
        private MetroFramework.Controls.MetroTextBox textBoxNetworkband;
        private MetroFramework.Controls.MetroTextBox textBoxNetworkMode;
        private MetroFramework.Controls.MetroButton buttonApplyAPI;
        private MetroFramework.Controls.MetroButton buttonpostAPI;
        private MetroFramework.Controls.MetroComboBox comboBoxAPIList;
        private MetroFramework.Controls.MetroTabPage metroTabPage7;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        public System.Windows.Forms.RichTextBox AboutLog;
        private System.Windows.Forms.Panel panel2;
        private MetroFramework.Controls.MetroButton metroButtonSIGNALMONITOR;
        private MetroFramework.Controls.MetroButton buttonWebpage;
        private System.Windows.Forms.Panel panel1;
        private System.ComponentModel.BackgroundWorker backgroundWorkerDetect_eerorCODE;
        private MetroFramework.Controls.MetroTabPage metroTabPage9;
        private MetroFramework.Controls.MetroButton btnSMSSend;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        public System.Windows.Forms.RichTextBox rtbSMSContent;
        private MetroFramework.Controls.MetroTextBox rtbSMSRecipient;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem copyPhoneNumberToolStripMenuItem;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.GroupBox groupBox14;
        private MetroFramework.Controls.MetroTabPage metroTabPage8;
        private MetroFramework.Controls.MetroButton metroButton2;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        public System.Windows.Forms.RichTextBox richTextBox3;
        private MetroFramework.Controls.MetroTextBox tbUSSDCMD;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroButton btnRefreshMAC;
    }
}

